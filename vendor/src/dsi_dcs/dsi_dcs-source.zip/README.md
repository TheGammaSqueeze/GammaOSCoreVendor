# dsi_dcs - fast DCS writes to the Retroid Pocket Duo panels

Out-of-tree kernel module for the RP Duo stock kernel. It creates
`/dev/dsi_dcs0` (top panel, vtdr6130) and `/dev/dsi_dcs1` (bottom panel,
il97680a). A write carries DSI command packets in the device-tree format
(binary): `<type> <last> <vc> <ack> <wait ms> <len hi> <len lo> <payload>`,
repeated. All packets of one write go out as one burst.

## Why

`panelsync` (vendor/src/panelsync) locks the top panel's refresh to the
bottom panel by adjusting the top DDIC's frame timing at runtime. The
display driver's own path for that, the connector debugfs `tx_cmd`, holds the
SDE kms VM lock for the whole transfer (40-70 ms measured), which stalls
commits on both panels: every correction cost a bottom-panel frame. This
module sends the same packets through the panel's `mipi_dsi_host` under only
that display's `display_lock` and panel lock, the debugfs path minus the
global lock (0.2 ms typical).

Safety: the module is compiled against the display driver headers. At load it
takes the display from the DSI host device's drvdata, requires the embedded
host to sit exactly at the host pointer, and requires the panel name to match
before it touches anything; otherwise it refuses to create the node.

## Inputs

- Kernel source matching the device (6.6.127):
  https://github.com/RPQ7790Dev/msm-kernel-diff (shallow clone is enough)
- Display driver source:
  https://github.com/RPQ7790Dev/display-drivers-diff
- Clang r510928, the toolchain the stock kernel was built with
  (AOSP prebuilts/clang/host/linux-x86/clang-r510928/bin)
- The device's kernel modules, for the symbol CRCs:
  `adb pull /vendor_dlkm/lib/modules device_mods/`
- `device.config`: the device kernel config (`adb shell zcat /proc/config.gz`,
  CRLF stripped), included here.

## Build

    git clone --depth 1 https://github.com/RPQ7790Dev/msm-kernel-diff.git kernel
    git clone --depth 1 https://github.com/RPQ7790Dev/display-drivers-diff.git display
    adb pull /vendor_dlkm/lib/modules device_mods/
    ./build.sh kernel display <aosp>/prebuilts/clang/host/linux-x86/clang-r510928/bin device_mods

`build.sh` prepares the kernel tree with `device.config` and
`KERNELRELEASE=6.6.127-android15-8-maybe-dirty-4k` (the device vermagic),
collects the symbol CRCs from the device modules' `__versions` sections
(`crcs.py`, so no vmlinux or Module.symvers is needed), and builds
`dsi_dcs.ko`. The kernel is not rebuilt.

The module is unsigned. The stock kernel has MODULE_SIG_PROTECT without
MODULE_SIG_FORCE, so it loads; it only uses ordinary exported symbols.

## Install

The vendor image carries it as `/vendor/lib/gammaos/dsi_dcs.ko`
(`u:object_r:vendor_kernel_modules:s0`), loaded by `init.panelsync.rc` before
panelsync starts. Manual test: `insmod dsi_dcs.ko debug=1` (logs each write's
timing at warning level).
