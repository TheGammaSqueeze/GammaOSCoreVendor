#!/bin/bash
# Builds dsi_dcs.ko for the RP Duo stock kernel (6.6.127-android15-8-maybe-dirty-4k).
# See README.md for the inputs. Usage: ./build.sh <kernel dir> <display dir> <clang bin dir> <device modules dir>
set -e
KDIR=$(realpath "$1"); DISPLAY_ROOT=$(realpath "$2"); CLANG=$(realpath "$3"); MODS=$(realpath "$4")
HERE=$(cd "$(dirname "$0")" && pwd)
export PATH="$CLANG:$PATH"
REL=6.6.127-android15-8-maybe-dirty-4k
# Kernel tree prepared with the device's own config (adb shell zcat /proc/config.gz).
if [ ! -f "$KDIR/include/generated/utsrelease.h" ] || ! grep -q "$REL" "$KDIR/include/generated/utsrelease.h"; then
    cp "$HERE/device.config" "$KDIR/.config"
    make -C "$KDIR" ARCH=arm64 LLVM=1 LLVM_IAS=1 olddefconfig
    make -C "$KDIR" ARCH=arm64 LLVM=1 LLVM_IAS=1 KERNELRELEASE=$REL modules_prepare -j"$(nproc)"
fi
# Symbol CRCs (modversions) from the device's own modules: no vmlinux needed.
(cd "$MODS/.." && python3 "$HERE/crcs.py" "$MODS" "$HERE/device.symvers")
make -C "$KDIR" ARCH=arm64 LLVM=1 LLVM_IAS=1 KERNELRELEASE=$REL M="$HERE" DISPLAY_ROOT="$DISPLAY_ROOT" \
     KBUILD_EXTRA_SYMBOLS="$HERE/device.symvers" modules
llvm-strip --strip-debug "$HERE/dsi_dcs.ko"
modinfo_vermagic=$(llvm-readelf -p .modinfo "$HERE/dsi_dcs.ko" | grep -o "vermagic=.*")
echo "built $HERE/dsi_dcs.ko ($modinfo_vermagic)"
