# Collect symbol CRCs from the __versions sections of the device's modules
# into a Module.symvers that modpost can use (KBUILD_EXTRA_SYMBOLS).
import sys, glob, struct
def sections(b):
    shoff,=struct.unpack_from('<Q',b,0x28); shentsize,shnum,shstrndx=struct.unpack_from('<HHH',b,0x3a)
    sh=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*shentsize) for i in range(shnum)]
    strtab=sh[shstrndx]
    for s in sh:
        name=b[strtab[4]+s[0]:].split(b'\0')[0].decode()
        yield name,b[s[4]:s[4]+s[5]]
crc={}
mods = sys.argv[1] if len(sys.argv) > 1 else 'device_mods'
out = sys.argv[2] if len(sys.argv) > 2 else 'device.symvers'
for ko in glob.glob(mods + '/**/*.ko', recursive=True):
    b=open(ko,'rb').read()
    for name,data in sections(b):
        if name!='__versions': continue
        for i in range(0,len(data)-63,64):
            c,=struct.unpack_from('<Q',data,i); n=data[i+8:i+64].split(b'\0')[0].decode()
            if n in crc and crc[n]!=c: print('conflict',n,file=sys.stderr)
            crc[n]=c
with open(out,'w') as f:
    for n,c in sorted(crc.items()):
        f.write('0x%08x\t%s\tvmlinux\tEXPORT_SYMBOL_GPL\t\n'%(c,n))
print(len(crc))
