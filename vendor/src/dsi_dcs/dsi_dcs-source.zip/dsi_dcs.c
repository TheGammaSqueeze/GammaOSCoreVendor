// SPDX-License-Identifier: GPL-2.0-only
/*
 * dsi_dcs - fast DCS writes to the RP Duo's DSI panels.
 *
 * The display driver's debugfs tx_cmd holds the SDE kms VM lock for the
 * whole transfer (40-70 ms on the Duo), which stalls every commit on both
 * panels: a bottom-panel flip refused or late per write. This module sends
 * the same packets through the panel's mipi_dsi_host, under only that
 * display's own display_lock and panel lock, exactly like the debugfs path
 * minus the global lock.
 *
 * /dev/dsi_dcs0 = qcom,dsi-display-primary, /dev/dsi_dcs1 = secondary.
 * A write carries DT-format packets (binary):
 *   <type> <last> <vc> <ack> <wait ms> <len hi> <len lo> <payload...>
 * repeated; every packet but the last of a write is batched into one burst.
 */
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/of.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/ktime.h>
#include <drm/drm_mipi_dsi.h>
#include "dsi_display.h"
#include "dsi_panel.h"

#define MAX_WRITE 512
#define MAX_PKTS  16

static bool debug;
module_param(debug, bool, 0644);

struct dcs_dev {
	const char *of_path;
	const char *panel_match;
	struct mipi_dsi_host *host;
	struct dsi_display *display;
	struct miscdevice misc;
	char name[16];
};

static struct dcs_dev devs[2] = {
	{ .of_path = "/soc/qcom,dsi-display-primary",   .panel_match = "vtdr6130" },
	{ .of_path = "/soc/qcom,dsi-display-secondary", .panel_match = "il97680a" },
};

static ssize_t dcs_write(struct file *f, const char __user *ubuf, size_t len, loff_t *off)
{
	struct dcs_dev *d = container_of(f->private_data, struct dcs_dev, misc);
	struct dsi_display *display = d->display;
	struct mipi_dsi_msg msgs[MAX_PKTS];
	u8 *buf;
	size_t pos = 0;
	int n = 0, i, rc = 0;
	ktime_t t0;

	if (len < 7 || len > MAX_WRITE)
		return -EINVAL;
	buf = memdup_user(ubuf, len);
	if (IS_ERR(buf))
		return PTR_ERR(buf);

	memset(msgs, 0, sizeof(msgs));
	while (pos + 7 <= len) {
		size_t plen = ((size_t)buf[pos + 5] << 8) | buf[pos + 6];

		if (n >= MAX_PKTS || pos + 7 + plen > len || plen == 0) {
			rc = -EINVAL;
			goto out;
		}
		msgs[n].type = buf[pos];
		msgs[n].channel = buf[pos + 2];
		msgs[n].tx_buf = buf + pos + 7;
		msgs[n].tx_len = plen;
		msgs[n].flags = MIPI_DSI_MSG_UNICAST_COMMAND;
		if (buf[pos + 3])
			msgs[n].flags |= MIPI_DSI_MSG_REQ_ACK;
		pos += 7 + plen;
		n++;
	}
	if (pos != len || n == 0) {
		rc = -EINVAL;
		goto out;
	}
	for (i = 0; i < n - 1; i++)
		msgs[i].flags |= MIPI_DSI_MSG_BATCH_COMMAND;

	t0 = ktime_get();
	mutex_lock(&display->display_lock);
	if (!display->enabled || !display->panel->panel_initialized) {
		rc = -EAGAIN;
	} else {
		s64 tp[MAX_PKTS];
		ktime_t tl = ktime_get();

		mutex_lock(&display->panel->panel_lock);
		tl = ktime_get();
		for (i = 0; i < n && rc >= 0; i++) {
			ktime_t ti = ktime_get();

			rc = d->host->ops->transfer(d->host, &msgs[i]);
			tp[i] = ktime_us_delta(ktime_get(), ti);
		}
		mutex_unlock(&display->panel->panel_lock);
		if (debug)
			pr_warn("dsi_dcs%d: locks %lld us, packets %lld %lld %lld us\n", (int)(d - devs),
				ktime_us_delta(tl, t0), tp[0], n > 1 ? tp[1] : 0, n > 2 ? tp[2] : 0);
	}
	mutex_unlock(&display->display_lock);
	if (debug)
		pr_warn("dsi_dcs%d: %d packets, rc %d, %lld us\n", (int)(d - devs), n, rc,
			ktime_us_delta(ktime_get(), t0));
out:
	kfree(buf);
	return rc < 0 ? rc : (ssize_t)len;
}

static const struct file_operations dcs_fops = {
	.owner = THIS_MODULE,
	.write = dcs_write,
	.llseek = noop_llseek,
};

static int __init dsi_dcs_init(void)
{
	int i, rc, ok = 0;

	for (i = 0; i < 2; i++) {
		struct dcs_dev *d = &devs[i];
		struct device_node *np = of_find_node_by_path(d->of_path);

		if (!np)
			continue;
		d->host = of_find_mipi_dsi_host_by_node(np);
		of_node_put(np);
		if (!d->host || !d->host->ops || !d->host->ops->transfer) {
			pr_err("dsi_dcs: no DSI host for %s\n", d->of_path);
			d->host = NULL;
			continue;
		}
		/* The structs come from the display driver's headers. The display
		 * is the platform drvdata of the host's device: its embedded host
		 * must sit exactly at the host pointer (a pure address check, no
		 * dereference through a guessed layout), and the panel must read
		 * back as the expected one, before anything else is touched. */
		d->display = d->host->dev ? dev_get_drvdata(d->host->dev) : NULL;
		if (!d->display || &d->display->host != d->host) {
			pr_err("dsi_dcs: %s: display layout mismatch\n", d->of_path);
			d->host = NULL;
			continue;
		}
		if (!d->display->panel || !d->display->panel->name ||
		    !strstr(d->display->panel->name, d->panel_match)) {
			pr_err("dsi_dcs: %s does not look like the %s panel, layout mismatch\n",
			       d->of_path, d->panel_match);
			d->host = NULL;
			continue;
		}
		snprintf(d->name, sizeof(d->name), "dsi_dcs%d", i);
		d->misc.minor = MISC_DYNAMIC_MINOR;
		d->misc.name = d->name;
		d->misc.fops = &dcs_fops;
		d->misc.mode = 0600;
		rc = misc_register(&d->misc);
		if (rc) {
			d->host = NULL;
			continue;
		}
		pr_info("dsi_dcs: /dev/%s -> %s (%s)\n", d->name, d->display->name, d->display->panel->name);
		ok++;
	}
	return ok ? 0 : -ENODEV;
}

static void __exit dsi_dcs_exit(void)
{
	int i;

	for (i = 0; i < 2; i++)
		if (devs[i].host)
			misc_deregister(&devs[i].misc);
}

module_init(dsi_dcs_init);
module_exit(dsi_dcs_exit);
MODULE_DESCRIPTION("Fast DCS writes to the RP Duo DSI panels");
MODULE_LICENSE("GPL v2");
